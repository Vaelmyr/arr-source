import { Injectable, Logger } from '@nestjs/common';
import { BaseProvider } from '../base.provider.js';
import { StreamingCommunityClient } from './streaming-community.client.js';
import type {
    ProviderMedia,
    ProviderMediaIdentity,
    ProviderRelease,
} from '../providers.types.js';
import type {
    StreamingCommunityEpisode,
    StreamingCommunitySeason,
    StreamingCommunityShow,
} from './streaming-community.types.js';
import type { SearchRequest } from '../../search/search.types.js';
import fs from 'node:fs';

@Injectable()
export class StreamingCommunityProvider extends BaseProvider {
    private readonly logger = new Logger(StreamingCommunityProvider.name);

    readonly id: string = 'streaming-community';
    readonly name: string = 'Streaming Community';

    readonly capabilities = {
        movies: true,
        tvShows: true,
        anime: false,
    };

    constructor(private readonly client: StreamingCommunityClient) {
        super();
    }

    public async search(request: SearchRequest): Promise<ProviderRelease[]> {
        this.logger.debug(
            `Searching on StreamingCommunity for Query=${request.query}, Season=${request.seasonNumber}, Episode=${request.episodeNumber}`,
        );

        const response = await this.client.search(request.query ?? '');

        const media = response.data
            .map((item) => this.mapMedia(item))
            .find(
                (media) => media !== undefined && this.matches(media, request),
            );

        if (!media) {
            return [];
        }

        return this.resolveReleases(media, request);
    }

    private mapMedia(item: StreamingCommunityShow): ProviderMedia | undefined {
        const identity = {
            id: `${item.id}-${item.slug}`,
            canonicalTitle: item.name,
            aliases: [],
            tmdbId: item.tmdb_id ? Number(item.tmdb_id) : undefined,
            tvdbId: undefined,
            imdbId: undefined,
        };

        switch (item.type) {
            case 'tv':
                return {
                    ...identity,
                    type: 'tv',
                };

            case 'movie':
                return {
                    ...identity,
                    type: 'movie',
                };
        }
    }

    private async resolveReleases(
        media: ProviderMedia,
        request: SearchRequest,
    ): Promise<ProviderRelease[]> {
        //TODO: Implement movie support
        if (media.type !== 'tv') {
            throw new Error(
                `Unsupported media type: ${media.type}. Only TV shows are currently supported.`,
            );
        }

        this.logger.debug(
            `Resolving releases for TV Show=${media.canonicalTitle}, Season=${request.seasonNumber}, Episode=${request.episodeNumber}`,
        );

        const season = await this.client.getSeason(
            media.id,
            request.seasonNumber ?? 1,
        );

        let episodes = season.episodes;

        this.logger.debug(
            `Fetched season episodes for TV Show=${media.canonicalTitle}, Season=${request.seasonNumber}`,
            JSON.stringify(episodes, null, 2),
        );

        if (request.episodeNumber !== undefined) {
            episodes = episodes.filter(
                (episode) => episode.number === request.episodeNumber,
            );
        }

        return episodes.map((episode) =>
            this.createEpisodeRelease(media, season, episode),
        );
    }

    private createEpisodeRelease(
        media: ProviderMedia,
        season: StreamingCommunitySeason,
        episode: StreamingCommunityEpisode,
    ): ProviderRelease {
        return {
            id: [media.id, episode.season_id, episode.id]
                .filter(Boolean)
                .join(':'),
            providerId: this.id,

            type: 'episode',

            title: episode.name ?? `Episode ${episode.number}`,

            mediaId: media.id,

            seasonNumber: season.number,
            episodeNumber: Number(episode.number),

            quality: episode.quality,
            size: episode.size,

            publishedAt: this.getPublishedDate(episode),
        };
    }

    private getPublishedDate(
        episode: StreamingCommunityEpisode,
    ): Date | undefined {
        if (episode.uploaded_at) {
            return new Date(episode.uploaded_at);
        }

        if (episode.updated_at) {
            return new Date(episode.updated_at);
        }

        if (episode.created_at) {
            return new Date(episode.created_at);
        }

        return new Date();
    }

    protected override matchesByTitle(
        media: ProviderMediaIdentity,
        request: SearchRequest,
    ): boolean {
        if (super.matchesByTitle(media, request)) {
            return true;
        }

        return this.matchesByLocalizedSubtitle(media, request);
    }

    private matchesByLocalizedSubtitle(
        media: ProviderMediaIdentity,
        request: SearchRequest,
    ): boolean {
        const normalizedRequestedTitle = this.normalizeTitle(
            request.query ?? '',
        );

        for (const separator of [' - ', ' – ', ' — ']) {
            const index = media.canonicalTitle.indexOf(separator);

            if (index <= 0) {
                continue;
            }

            const baseTitle = media.canonicalTitle.slice(0, index);

            if (this.normalizeTitle(baseTitle) === normalizedRequestedTitle) {
                return true;
            }
        }

        return false;
    }
}
